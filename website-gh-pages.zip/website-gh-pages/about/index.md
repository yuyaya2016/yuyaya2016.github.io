---
layout: page
type: about me
---

I am a data enthusiast with 4-year work experience in business innovation, data analytics and visualization, and statistical modeling. 
